//
//  MyCustomCell.swift
//  Desafios-App1
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import UIKit

class MyCustomCell: UITableViewCell {
    
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelCargo: UILabel!
    @IBOutlet weak var labelEmail: UILabel!
    
    
    func setup(person: Person) {
        labelName.text = ""
        labelName.text = person.name
        labelCargo.text = ""
        labelCargo.text = person.cargo
        labelEmail.text = ""
        labelEmail.text = person.email
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
