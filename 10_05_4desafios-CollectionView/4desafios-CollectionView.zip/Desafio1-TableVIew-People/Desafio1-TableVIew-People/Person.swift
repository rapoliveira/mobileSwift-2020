//
//  People.swift
//  Desafios-App1
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import Foundation

class Person {
    var name: String?
    var cargo: String?
    var email: String?
    
    init(name: String, cargo: String, email: String) {
        self.name = name
        self.cargo = cargo
        self.email = email
    }
}
