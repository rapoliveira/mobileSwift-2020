//
//  ViewController.swift
//  Desafios-App1
//
//  Created by Raphael A. P. Oliveira on 04/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var TableViewPeople: UITableView!
    
    // Caso tenha um botão para abrir modal
    //@IBAction func actionOpenModal(_ sender: Any) {
    //
    //}
    
    var arrayPeople = [Person]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        TableViewPeople.delegate = self
        TableViewPeople.dataSource = self
        arrayPeople.append(Person(name: "Raphael A. P. Oliveira", cargo: "Cientista", email: "aaa@gmail.com"))
        arrayPeople.append(Person(name: "Narlei Moreira", cargo: "Professor", email: "bbb@gmail.com"))
        arrayPeople.append(Person(name: "Jessica Santana", cargo: "Professora", email: "ccc@gmail.com"))
        arrayPeople.append(Person(name: "Paolo Lopes", cargo: "Engenheiro", email: "ddd@email.com"))
        arrayPeople.append(Person(name: "Marcelo Squarisi", cargo: "Analista", email: "eee@email.com"))
        arrayPeople.append(Person(name: "Cesar Tavares", cargo: "Programador", email: "fff@gmail.com"))
        arrayPeople.append(Person(name: "Gilvã Rocha", cargo: "Estagiário", email: "ggg@gmail.com"))
        arrayPeople.append(Person(name: "Jorge de Carvalho", cargo: "Estudante", email: "hhh@gmail.com"))
        arrayPeople.append(Person(name: "Rafael Rios", cargo: "Gerente", email: "iii@email.com"))
        arrayPeople.append(Person(name: "Dominique Bezerra", cargo: "Supervisor", email: "jjj@email.com"))
        arrayPeople.append(Person(name: "Gustavo Schwarz", cargo: "Vendedor", email: "kkk@gmail.com"))
        arrayPeople.append(Person(name: "Mauro Juliano", cargo: "Caixa", email: "lll@gmail.com"))
        arrayPeople.append(Person(name: "Thiago Messa", cargo: "Assistente", email: "mmm@gmail.com"))
        arrayPeople.append(Person(name: "Mízia Lima", cargo: "Contador", email: "nnn@email.com"))
        arrayPeople.append(Person(name: "Luciana Santana", cargo: "Designer", email: "ooo@email.com"))
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let employee = arrayPeople[indexPath.row]
        print (employee)
        
        if let viewControllerDetail = UIStoryboard(name: "PersonDetail", bundle: nil).instantiateInitialViewController() as? PersonDetailViewController {
            
            // Navigation Controller
            //navigationController?.pushViewController(viewControllerDetail, animated: true)
            
            // Abre a tela MODAL
            viewControllerDetail.employee = arrayPeople[indexPath.row]
            present(viewControllerDetail, animated: true, completion: nil)
            
        }
        
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        arrayPeople.remove(at: indexPath.row)
        TableViewPeople.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayPeople.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellCustom", for: indexPath) as! MyCustomCell
        
        cell.setup(person: arrayPeople[indexPath.row])
        
        return cell
    }
    
}
