//
//  MyCustomCell.swift
//  Desafios-Ex2
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import UIKit

class MyCustomCell: UITableViewCell {
    
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelBreed: UILabel!
    @IBOutlet weak var labelWeight: UILabel!
    @IBOutlet weak var labelSpecie: UILabel!
    
    func setup(animal: Animal) {
        labelName.text = ""
        labelName.text = animal.name
        labelBreed.text = ""
        labelBreed.text = animal.breed
        labelWeight.text = ""
        labelWeight.text = animal.weight
        labelSpecie.text = ""
        labelSpecie.text = animal.specie
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
