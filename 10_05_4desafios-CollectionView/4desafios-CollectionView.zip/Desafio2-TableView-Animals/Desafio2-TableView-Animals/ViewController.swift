//
//  ViewController.swift
//  Desafios-Ex2
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import UIKit

// Exercício 02 - Criar um app:
// - Tenha uma lista (tableView) com 10 animais.
// - Cada célula (linha) deve ter o nome, raça, peso e espécie de um animal.
// - Quando tocar numa celula, deve abrir uma tela em modal, nessa tela deve haver
//   um botão de fechar e um label com o nome do animal.

class ViewController: UIViewController {
    
    @IBOutlet weak var TableViewAnimals: UITableView!
    
    var arrayAnimals = [Animal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        TableViewAnimals.delegate = self
        TableViewAnimals.dataSource = self
        arrayAnimals.append(Animal(name: "Raj", breed: "Shih-tzu", weight: "7 kg", specie: "Dog"))
        arrayAnimals.append(Animal(name: "Thor", breed: "Border Collie", weight: "10 kg", specie: "Dog"))
        arrayAnimals.append(Animal(name: "Rex", breed: "Rotweiller", weight: "30 kg", specie: "Dog"))
        arrayAnimals.append(Animal(name: "Marie", breed: "Persian", weight: "3 kg", specie: "Cat"))
        arrayAnimals.append(Animal(name: "Pluto", breed: "Husky", weight: "40 kg", specie: "Dog"))
        arrayAnimals.append(Animal(name: "Polly", breed: "Poodle", weight: "4 kg", specie: "Dog"))
        arrayAnimals.append(Animal(name: "Einstein", breed: "Golden", weight: "30 kg", specie: "Dog"))
        arrayAnimals.append(Animal(name: "Tobby", breed: "Pitbull", weight: "20 kg", specie: "Dog"))
        arrayAnimals.append(Animal(name: "Pink", breed: "Pug", weight: "5 kg", specie: "Dog"))
        arrayAnimals.append(Animal(name: "Spirit", breed: "Horse", weight: "200 kg", specie: "Horse"))
    }

}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let animal = arrayAnimals[indexPath.row]
        print (animal)
        
        if let viewControllerDetail = UIStoryboard(name: "AnimalDetail", bundle: nil).instantiateInitialViewController() as? AnimalDetailViewController {
            
            // Navigation Controller
            //navigationController?.pushViewController(viewControllerDetail, animated: true)
            // Abre a tela MODAL
            viewControllerDetail.animal = arrayAnimals[indexPath.row]
            present(viewControllerDetail, animated: true, completion: nil)
            
        }
        
    }
    
    
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        arrayAnimals.remove(at: indexPath.row)
        TableViewAnimals.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayAnimals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellCustom", for: indexPath) as! MyCustomCell
        cell.setup(animal: arrayAnimals[indexPath.row])
        
        return cell
    }
    
    
}
