//
//  Animal.swift
//  Desafios-Ex2
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import Foundation

class Animal {
    
    var name: String
    var breed: String
    var weight: String
    var specie: String
    
    init(name: String, breed: String, weight: String, specie: String) {
        self.name = name
        self.breed = breed
        self.weight = weight
        self.specie = specie
    }
    
}
