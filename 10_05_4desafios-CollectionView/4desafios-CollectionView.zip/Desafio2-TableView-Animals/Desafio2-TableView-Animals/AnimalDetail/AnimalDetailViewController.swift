//
//  AnimalDetailViewController.swift
//  Desafios-Ex2
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import UIKit

class AnimalDetailViewController: UIViewController {
    
    @IBOutlet weak var labelNameModal: UILabel!
    @IBOutlet weak var labelBreedModal: UILabel!
    @IBOutlet weak var labelWeightModal: UILabel!
    @IBOutlet weak var labelSpecieModal: UILabel!
    
    @IBAction func actionButtonClose(_ sender: Any) {
        //Navigation
        //navigationController?.popViewController(animated: true)
        // MODAL:
        dismiss(animated: true, completion: nil)
    }
    
    var animal: Animal?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        labelNameModal.text = ""
        labelNameModal.text = animal?.name
        labelBreedModal.text = ""
        labelBreedModal.text = animal?.breed
        labelWeightModal.text = ""
        labelWeightModal.text = animal?.weight
        labelSpecieModal.text = ""
        labelSpecieModal.text = animal?.specie

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
