//
//  CarCell.swift
//  Desafios-Ex3
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import UIKit

class CarCell: UICollectionViewCell {
    
    @IBOutlet weak var labelName: UILabel?
    @IBOutlet weak var imageViewPhoto: UIImageView?
    
    func setup(car: Car) {
        labelName?.text = car.name
        imageViewPhoto?.image = UIImage(named: car.image)
    }
    
}
