//
//  ViewController.swift
//  Desafios-Ex3
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import UIKit

// 03 - Criar um app:
// - Tenha uma collectionview com 10 carros na vertical;
// - Cada célula deve ter o nome e a imagem do carro; (pode repetir a mesma imagem)
// - Quando tocar numa celula, deve abrir uma tela via navigation (push), nessa tela
// deve haver a imagem grande.


class ViewController: UIViewController {
    
    @IBOutlet weak var collectionViewCars: UICollectionView!
    
    var arrayCars = [Car]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionViewCars.delegate = self
        collectionViewCars.dataSource = self
        
        arrayCars.append(Car(name: "Fusca", image: "carro.jpg"))
        arrayCars.append(Car(name: "Gol", image: "carro.jpg"))
        arrayCars.append(Car(name: "C3", image: "carro.jpg"))
        arrayCars.append(Car(name: "Ônix", image: "carro.jpg"))
        arrayCars.append(Car(name: "Saveiro", image: "carro.jpg"))
        arrayCars.append(Car(name: "Niva", image: "carro.jpg"))
        arrayCars.append(Car(name: "Celta", image: "carro.jpg"))
        arrayCars.append(Car(name: "Chevette", image: "carro.jpg"))
        arrayCars.append(Car(name: "Subaru", image: "carro.jpg"))
        arrayCars.append(Car(name: "Eclipse", image: "carro.jpg"))
        collectionViewCars.reloadData()
    }
    
}

extension ViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let car = arrayCars[indexPath.row]
        
        //if let carDetail = UIStoryboard(name: "CarDetail", bundle: nil).instantiateInitialViewController() as? CarDetailViewController {
        //    navigationController?.pushViewController(carDetail, animated: true)
        //    carDetail.car = arrayCars[indexPath.row]
        //}
        
        if let viewDetail = CarDetailViewController.getViewController() {
            viewDetail.car = arrayCars[indexPath.row]
            
            navigationController?.pushViewController(viewDetail, animated: true)
        }
        
    }
    
}

extension ViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrayCars.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CarCell", for: indexPath) as! CarCell
        
        cell.setup(car: arrayCars[indexPath.row])
        
        return cell
    }
    
    
}

