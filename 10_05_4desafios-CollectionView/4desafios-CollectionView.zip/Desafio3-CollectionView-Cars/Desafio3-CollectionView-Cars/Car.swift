//
//  Car.swift
//  Desafios-Ex3
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import Foundation

class Car {
    var name: String
    var image: String
    
    init(name: String, image: String) {
        self.name = name
        self.image = image
    }
}
