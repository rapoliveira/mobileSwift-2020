//
//  CarDetailViewController.swift
//  Desafios-Ex3
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import UIKit

class CarDetailViewController: UIViewController {

    var car: Car?
    @IBOutlet weak var carImageNavigation: UIImageView!
    @IBOutlet weak var labelNameNavigation: UILabel!
    
    @IBAction func actionButtonClose(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let car = car {
            carImageNavigation?.image = UIImage(named: car.image)
            title = car.name
            labelNameNavigation.text = ""
            labelNameNavigation.text = car.name
        }
    }
        
    static func getViewController() -> CarDetailViewController? {
            if let viewDetail = UIStoryboard(name: "CarDetail", bundle: nil).instantiateInitialViewController() as? CarDetailViewController {
                return viewDetail
            }
            return nil
    }

}
