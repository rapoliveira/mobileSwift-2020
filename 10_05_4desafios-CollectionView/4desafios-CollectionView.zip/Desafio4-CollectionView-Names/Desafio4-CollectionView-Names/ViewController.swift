//
//  ViewController.swift
//  Desafios-Ex4-Collection-Nomes
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
        
    @IBOutlet weak var namesCollectionView: UICollectionView!
    
    var arrayNames = ["Raphael", "Gabrielle", "Ronaldo", "Thor", "Chris", "Maria", "João",
                      "Paulo", "Marcel", "Cleide", "Plínio", "Fernando", "Otávio", "Narlei",
                      "Eduardo", "Felipe", "Mark", "Ana", "Harold", "Júnior"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        namesCollectionView.delegate = self
        namesCollectionView.dataSource = self
        
    }
}

extension ViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print ("\(arrayNames[indexPath.row]) was removed from the Collection View!")
        arrayNames.remove(at: indexPath.row)
        print ("Collection View is now with \(arrayNames.count) members.\n")
        collectionView.reloadData()
    }
}

extension ViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrayNames.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NameCollectionViewCell", for: indexPath) as! NamesCollectionViewCell
        cell.setup(name: arrayNames[indexPath.row])
        return cell
    }
    
    private func collectionView(_ collectionView: UICollectionView, canEditItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    
}
