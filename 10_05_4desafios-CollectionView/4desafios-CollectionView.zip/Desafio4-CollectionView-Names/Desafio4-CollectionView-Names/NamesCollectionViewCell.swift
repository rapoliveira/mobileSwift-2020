//
//  NamesCollectionViewCell.swift
//  Desafios-Ex4-Collection-Nomes
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import UIKit

class NamesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var labelName: UILabel!
    
    func setup(name: String) {
        labelName.text = name
    }
}
