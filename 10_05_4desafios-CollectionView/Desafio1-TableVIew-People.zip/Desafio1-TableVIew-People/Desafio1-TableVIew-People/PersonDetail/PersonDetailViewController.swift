//
//  PersonDetailViewController.swift
//  Desafios-App1
//
//  Created by Raphael A. P. Oliveira on 05/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import UIKit

class PersonDetailViewController: UIViewController {

    @IBOutlet weak var labelNameModal: UILabel!
    
    @IBAction func actionButtonClose(_ sender: Any) {
        //Navigation
        //navigationController?.popViewController(animated: true)
        // MODAL:
        dismiss(animated: true, completion: nil)
    }
    
    var employee: Person?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        labelNameModal.text = ""
        labelNameModal.text = employee?.name
        
    }

}
