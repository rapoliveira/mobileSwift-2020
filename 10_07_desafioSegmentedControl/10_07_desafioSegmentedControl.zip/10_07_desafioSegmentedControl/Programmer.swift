//
//  Programmer.swift
//  10_07_desafioSegmentedControl
//
//  Created by Raphael A. P. Oliveira on 07/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import Foundation

class Programmer: Person {
    
    var role: String
    
    init (role: String)
    
}
