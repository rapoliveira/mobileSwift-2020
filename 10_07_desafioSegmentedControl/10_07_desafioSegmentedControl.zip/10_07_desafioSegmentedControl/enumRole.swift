//
//  enumRole.swift
//  10_07_desafioSegmentedControl
//
//  Created by Raphael A. P. Oliveira on 07/10/20.
//  Copyright © 2020 Raphael A. P. Oliveira. All rights reserved.
//

import Foundation

enum Role {
    static let programmer = 0
    static let person = 1
}
